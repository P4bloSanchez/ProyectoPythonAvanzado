import sys

def verificarArgumentos():
	return sys.path