import sys

def meterRuta(route):
	sys.path.append(route)